# Product_Recommendations
This project is to generate product recommendation model developed using collaborative filtering technique in machine learning. To recommend products to retail store customers and identify buying patterns for product purchased frequently together by the members of the store.
